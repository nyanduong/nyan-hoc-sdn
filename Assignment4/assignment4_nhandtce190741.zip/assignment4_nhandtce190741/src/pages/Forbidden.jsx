import { Link } from "react-router-dom";
import Icon from "../components/Icon";

export default function Forbidden() {
  return (
    <section className="empty-state standalone-state">
      <span className="state-icon">
        <Icon name="shield" size={30} />
      </span>
      <p className="eyebrow">403 / FORBIDDEN</p>
      <h1>This space is for admins.</h1>
      <p>Your account does not have permission to create reports.</p>
      <Link className="btn btn-primary" to="/reports">
        Back to my reports <Icon name="arrow" size={17} />
      </Link>
    </section>
  );
}
