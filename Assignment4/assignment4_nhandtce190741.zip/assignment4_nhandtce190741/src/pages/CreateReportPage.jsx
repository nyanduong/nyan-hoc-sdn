import { useState } from "react";
import { Link } from "react-router-dom";
import { createReport } from "../services/api";
import { errorMessage } from "../api/client";
import Feedback from "../components/Feedback";
import Icon from "../components/Icon";

export default function CreateReportPage() {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(null);

  async function submit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity() || pending) return;
    const values = Object.fromEntries(
      [...new FormData(form)].map(([key, value]) => [key, value.trim()]),
    );
    if (Object.values(values).some((value) => !value)) {
      setError("Please complete every required field.");
      return;
    }
    setPending(true);
    setError("");
    setSuccess(null);
    try {
      const result = await createReport(values);
      setSuccess(result);
      form.reset();
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setPending(false);
    }
  }

  return (
    <>
      <Link to="/reports" className="back-link">
        ← Back to my reports
      </Link>
      <div className="page-heading">
        <div>
          <p className="eyebrow">GIVE THE NEXT FIX A HEAD START</p>
          <h1>
            Create a report<span className="heading-dot">.</span>
          </h1>
          <p className="intro">
            A clear description today. A smoother fix tomorrow.
          </p>
        </div>
        <span className="admin-tag">
          <Icon name="shield" size={15} /> Admin workspace
        </span>
      </div>
      <Feedback>{error}</Feedback>
      {success && (
        <Feedback type="success">
          <strong>{success.message || "Report created successfully"}</strong>
          {success.report && (
            <div className="mt-1">
              “{success.report.title}” has been assigned. Status:{" "}
              {success.report.status || "open"}.<br />
              <small>Report ID: {success.report._id}</small>
            </div>
          )}
        </Feedback>
      )}
      <div className="create-grid">
        <section className="form-panel">
          <div className="panel-heading">
            <div>
              <h2>Report details</h2>
              <p>All fields are required.</p>
            </div>
            <Icon name="bug" />
          </div>
          <form onSubmit={submit} className="report-form">
            <fieldset disabled={pending}>
              <div className="mb-4">
                <label htmlFor="title" className="form-label">
                  Report title
                </label>
                <input
                  className="form-control"
                  id="title"
                  name="title"
                  placeholder="A short, specific summary of the issue"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="description" className="form-label">
                  Description
                </label>
                <textarea
                  className="form-control"
                  id="description"
                  name="description"
                  rows="6"
                  placeholder="What happened? What did you expect? Include steps to reproduce the issue."
                  required
                />
              </div>
              <div className="row">
                <div className="col-sm-7 mb-4">
                  <label htmlFor="project" className="form-label">
                    Project
                  </label>
                  <input
                    className="form-control"
                    id="project"
                    name="project"
                    placeholder="Project name"
                    required
                  />
                </div>
                <div className="col-sm-5 mb-4">
                  <label htmlFor="severity" className="form-label">
                    Severity
                  </label>
                  <select
                    className="form-select"
                    id="severity"
                    name="severity"
                    defaultValue="low"
                    required
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
              </div>
              <div className="mb-4">
                <label htmlFor="assignedTo" className="form-label">
                  Assigned to · User ID
                </label>
                <input
                  className="form-control font-monospace"
                  id="assignedTo"
                  name="assignedTo"
                  placeholder="24-character user ID"
                  pattern="[a-fA-F0-9]{24}"
                  title="Enter a valid 24-character MongoDB user ID"
                  aria-describedby="assigned-help"
                  required
                />
                <div id="assigned-help" className="form-text">
                  Enter the ID of an existing account with the User role. That
                  user can find their ID in the sidebar after signing in.
                </div>
              </div>
              <div className="form-actions">
                <Link className="btn btn-outline-secondary" to="/reports">
                  Cancel
                </Link>
                <button className="btn btn-primary" type="submit">
                  {pending ? (
                    <>
                      <span
                        className="spinner-border spinner-border-sm"
                        aria-hidden="true"
                      />{" "}
                      Creating…
                    </>
                  ) : (
                    <>
                      <Icon name="plus" size={18} /> Create report
                    </>
                  )}
                </button>
              </div>
            </fieldset>
          </form>
        </section>
        <aside className="report-tips">
          <span className="tips-icon">
            <Icon name="bug" size={25} />
          </span>
          <h2>
            A good report
            <br />
            goes a long way.
          </h2>
          <p>
            Give your teammate enough context to reproduce and understand the
            issue.
          </p>
          <ol>
            <li>
              <strong>Make it specific</strong>
              <span>Use a title that describes the problem.</span>
            </li>
            <li>
              <strong>Show the steps</strong>
              <span>Explain how to reproduce it, and what you expected.</span>
            </li>
            <li>
              <strong>Find the right person</strong>
              <span>Assign an existing User account to take it from here.</span>
            </li>
          </ol>
          <div className="tips-footer">
            <span className="status-badge status-open">open</span>
            <p>New reports start with an Open status.</p>
          </div>
        </aside>
      </div>
    </>
  );
}
