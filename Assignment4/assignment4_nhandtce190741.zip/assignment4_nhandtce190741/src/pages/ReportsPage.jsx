import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { fetchReports } from "../services/api";
import { errorMessage } from "../api/client";
import { useAuth } from "../context/AuthContext";
import Feedback from "../components/Feedback";
import Icon from "../components/Icon";

export default function ReportsPage() {
  const { user } = useAuth();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [revision, setRevision] = useState(0);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const requestVersion = useRef(0);

  useEffect(() => {
    const controller = new AbortController();
    const version = ++requestVersion.current;
    setLoading(true);
    setError("");
    fetchReports(controller.signal)
      .then((data) => {
        if (!Array.isArray(data))
          throw new Error("The server returned an unexpected reports format.");
        if (version === requestVersion.current) setReports(data);
      })
      .catch((err) => {
        if (!controller.signal.aborted && version === requestVersion.current)
          setError(errorMessage(err));
      })
      .finally(() => {
        if (!controller.signal.aborted && version === requestVersion.current)
          setLoading(false);
      });
    return () => controller.abort();
  }, [revision]);

  const filtered = reports.filter((report) => {
    const text =
      `${report.title} ${report.project} ${report.assignedTo?.username || ""}`.toLowerCase();
    return (
      text.includes(query.toLowerCase().trim()) &&
      (status === "all" || report.status === status)
    );
  });
  const stats = [
    {
      label: "Assigned to you",
      value: reports.length,
      icon: "grid",
      style: "total",
      caption: "Your reports, in one place",
    },
    {
      label: "Open & in progress",
      value: reports.filter((r) => ["open", "in-progress"].includes(r.status))
        .length,
      icon: "clock",
      style: "active",
      caption: "Ready for your attention",
    },
    {
      label: "Resolved & closed",
      value: reports.filter((r) => ["resolved", "closed"].includes(r.status))
        .length,
      icon: "check",
      style: "done",
      caption: "A little progress, every day",
    },
  ];

  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">THE WORK, AT A GLANCE</p>
          <h1>
            My reports<span className="heading-dot">.</span>
          </h1>
          <p className="intro">A clear view of the bugs assigned to you.</p>
        </div>
        {user.role === "admin" && (
          <Link to="/reports/create" className="btn btn-primary">
            <Icon name="plus" size={18} /> Create report
          </Link>
        )}
      </div>
      <div className="stats-grid">
        {stats.map((stat) => (
          <section className={`stat-card ${stat.style}`} key={stat.label}>
            <div className="stat-top">
              <span>{stat.label}</span>
              <Icon name={stat.icon} />
            </div>
            <strong>{loading || error ? "—" : stat.value}</strong>
            <span className="stat-caption">{stat.caption}</span>
          </section>
        ))}
      </div>
      <section
        className="reports-panel"
        aria-labelledby="report-list-title"
        aria-busy={loading}
      >
        <div className="panel-heading">
          <div>
            <h2 id="report-list-title">
              Report overview{" "}
              <span className="count-tag">
                {loading || error ? "—" : reports.length}
              </span>
            </h2>
            <p>Every detail you need to take the next step.</p>
          </div>
          <button
            className="btn btn-outline-secondary btn-sm"
            onClick={() => setRevision((n) => n + 1)}
            disabled={loading}
          >
            Refresh
          </button>
        </div>
        <div className="report-toolbar">
          <div className="search-field">
            <Icon name="search" size={18} />
            <input
              aria-label="Search reports"
              placeholder="Search by title, project or assignee…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <select
            className="form-select status-filter"
            aria-label="Filter by status"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="all">All statuses</option>
            <option value="open">Open</option>
            <option value="in-progress">In progress</option>
            <option value="resolved">Resolved</option>
            <option value="closed">Closed</option>
          </select>
        </div>
        {loading ? (
          <div className="empty-state" role="status">
            <span className="spinner-border text-success" aria-hidden="true" />
            <h3>Loading your reports…</h3>
            <p>Gathering the latest from your workspace.</p>
          </div>
        ) : error ? (
          <div className="panel-feedback">
            <Feedback>{error}</Feedback>
            <button
              className="btn btn-outline-secondary"
              onClick={() => setRevision((n) => n + 1)}
            >
              Try again
            </button>
          </div>
        ) : reports.length === 0 ? (
          <div className="empty-state">
            <span className="state-icon">
              <Icon name="check" size={29} />
            </span>
            <h3>A little breathing room.</h3>
            <p>
              No reports are assigned to you yet.
              <br />
              New assignments will appear here.
            </p>
            {user.role === "admin" && (
              <Link to="/reports/create" className="text-link">
                Create a report <Icon name="arrow" size={16} />
              </Link>
            )}
          </div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <span className="state-icon">
              <Icon name="search" size={28} />
            </span>
            <h3>No matching reports.</h3>
            <p>Try a different search or status.</p>
            <button
              className="btn btn-outline-secondary btn-sm"
              onClick={() => {
                setQuery("");
                setStatus("all");
              }}
            >
              Clear filters
            </button>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table report-table">
              <thead>
                <tr>
                  <th scope="col">REPORT TITLE</th>
                  <th scope="col">PROJECT</th>
                  <th scope="col">SEVERITY</th>
                  <th scope="col">STATUS</th>
                  <th scope="col">ASSIGNED TO</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((report) => (
                  <tr key={report._id}>
                    <td>
                      <strong>{report.title}</strong>
                      {report.description && (
                        <details className="report-description">
                          <summary>View description</summary>
                          <p>{report.description}</p>
                        </details>
                      )}
                    </td>
                    <td>{report.project}</td>
                    <td>
                      <span className={`severity severity-${report.severity}`}>
                        <span aria-hidden="true">●</span> {report.severity}
                      </span>
                    </td>
                    <td>
                      <span className={`status-badge status-${report.status}`}>
                        {report.status?.replace("-", " ")}
                      </span>
                    </td>
                    <td>
                      <span className="assignee">
                        <span className="mini-avatar">
                          {(report.assignedTo?.username ||
                            "?")[0].toUpperCase()}
                        </span>
                        {report.assignedTo?.username ||
                          report.assignedTo?.email ||
                          "Unavailable user"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {!loading && !error && reports.length > 0 && (
          <div className="table-footnote">
            Showing {filtered.length} of {reports.length} assigned reports
          </div>
        )}
      </section>
      <div className="scope-note">
        <Icon name="shield" size={16} />
        <span>
          Just your assignments. This view shows reports assigned to your
          account.
        </span>
      </div>
    </>
  );
}
