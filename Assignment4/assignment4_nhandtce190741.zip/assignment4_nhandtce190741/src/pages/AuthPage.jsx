import { useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { signin, signup } from "../services/api";
import { errorMessage } from "../api/client";
import Feedback from "../components/Feedback";
import Icon from "../components/Icon";

export default function AuthPage({ register = false }) {
  const { user, login, sessionMessage } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  if (user) return <Navigate to="/reports" replace />;

  async function submit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity() || pending) return;
    const values = Object.fromEntries(new FormData(form));
    values.email = values.email.trim();
    if (register) {
      values.username = values.username.trim();
      if (!values.username) {
        setError("Please enter a username.");
        return;
      }
    }
    if (!values.password.trim()) {
      setError("Please enter a password.");
      return;
    }
    setPending(true);
    setError("");
    try {
      if (register) {
        const result = await signup(values);
        navigate("/signin", {
          replace: true,
          state: {
            success: result.message || "Account created. You can now sign in.",
          },
        });
      } else {
        const result = await signin(values);
        const identity = login(result.token);
        const target = location.state?.from;
        navigate(
          target === "/reports/create" && identity.role === "admin"
            ? target
            : "/reports",
          { replace: true },
        );
      }
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="auth-layout">
      <aside className="auth-story">
        <Link className="brand" to="/signin">
          <span className="brand-symbol">
            <Icon name="bug" size={23} />
          </span>
          bugdesk<span className="brand-dot">.</span>
        </Link>
        <div className="story-content">
          <span className="story-kicker">SMALL BUGS. BIG PICTURE.</span>
          <h1>
            Good projects
            <br />
            start with
            <br />
            <em>clear reports.</em>
          </h1>
          <p>
            A focused home for your team's bugs.
            <br />
            Track what matters. Keep moving forward.
          </p>
          <div className="story-art" aria-hidden="true">
            <div className="art-orbit" />
            <div className="art-ticket">
              <span className="art-dot" />
              <span>One less bug.</span>
              <span className="art-check">
                <Icon name="check" size={21} />
              </span>
            </div>
            <div className="art-ticket art-ticket-back">
              <Icon name="bug" />
              <div className="art-lines">
                <i />
                <i />
              </div>
            </div>
          </div>
        </div>
        <div className="story-footer">
          <span>BUILT FOR BETTER WORK</span>
          <span>01 — 04</span>
        </div>
      </aside>
      <main className="auth-main">
        <div className="auth-form-wrap">
          <span className="eyebrow">YOUR BUGDESK WORKSPACE</span>
          <h2>{register ? "Make yourself at home." : "Welcome back."}</h2>
          <p className="intro">
            {register
              ? "Create an account to get started with your team."
              : "Sign in to see what needs your attention."}
          </p>
          <Feedback>{error}</Feedback>
          {!register && (
            <Feedback type="success">{location.state?.success}</Feedback>
          )}
          {!register && <Feedback type="warning">{sessionMessage}</Feedback>}
          <form onSubmit={submit}>
            <fieldset disabled={pending}>
              {register && (
                <div className="mb-3">
                  <label htmlFor="username" className="form-label">
                    Username
                  </label>
                  <input
                    id="username"
                    name="username"
                    className="form-control"
                    placeholder="Your name"
                    autoComplete="username"
                    required
                  />
                </div>
              )}
              <div className="mb-3">
                <label htmlFor="email" className="form-label">
                  Email address
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  className="form-control"
                  placeholder="you@example.com"
                  autoComplete="email"
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="password" className="form-label">
                  Password
                </label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  className="form-control"
                  placeholder={
                    register ? "Choose a password" : "Enter your password"
                  }
                  autoComplete={register ? "new-password" : "current-password"}
                  required
                />
              </div>
              {register && (
                <div className="mb-4">
                  <label htmlFor="role" className="form-label">
                    Account role
                  </label>
                  <select
                    id="role"
                    name="role"
                    className="form-select"
                    defaultValue="user"
                  >
                    <option value="user">User</option>
                    <option value="moderator">Moderator</option>
                    <option value="admin">Admin</option>
                  </select>
                  <div className="form-text">
                    Users receive reports. Admins can create and assign them.
                  </div>
                </div>
              )}
              <button
                className="btn btn-primary w-100 auth-submit"
                type="submit"
              >
                {pending ? (
                  <>
                    <span
                      className="spinner-border spinner-border-sm"
                      aria-hidden="true"
                    />{" "}
                    {register ? "Creating account…" : "Signing in…"}
                  </>
                ) : (
                  <>
                    {register ? "Create account" : "Sign in"}{" "}
                    <Icon name="arrow" size={18} />
                  </>
                )}
              </button>
            </fieldset>
          </form>
          <p className="auth-switch">
            {register ? "Already have an account?" : "New to Bugdesk?"}{" "}
            <Link to={register ? "/signin" : "/signup"}>
              {register ? "Sign in" : "Create an account"}{" "}
              <span aria-hidden="true">↗</span>
            </Link>
          </p>
          <div className="auth-footnote">
            <Icon name="shield" size={16} />
            <span>Your workspace, securely connected.</span>
          </div>
        </div>
        <footer className="auth-bottom">
          SDN302 · Assignment 04 <span>nhandtce190741</span>
        </footer>
      </main>
    </div>
  );
}
