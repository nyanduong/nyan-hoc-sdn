import { Link, Navigate, Route, Routes } from "react-router-dom";
import AuthPage from "./pages/AuthPage";
import ReportsPage from "./pages/ReportsPage";
import CreateReportPage from "./pages/CreateReportPage";
import ProtectedRoute from "./routes/ProtectedRoute";
import Layout from "./components/Layout";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/reports" replace />} />
      <Route path="/signin" element={<AuthPage key="signin" />} />
      <Route path="/signup" element={<AuthPage key="signup" register />} />
      <Route element={<ProtectedRoute />}>
        <Route element={<Layout />}>
          <Route path="/reports" element={<ReportsPage />} />
          <Route element={<ProtectedRoute adminOnly />}>
            <Route path="/reports/create" element={<CreateReportPage />} />
          </Route>
        </Route>
      </Route>
      <Route
        path="*"
        element={
          <main className="empty-state standalone-state">
            <p className="eyebrow">404 / NOT FOUND</p>
            <h1>That page got away.</h1>
            <p>Let's get you back to your workspace.</p>
            <Link className="btn btn-primary" to="/reports">
              Go to my reports
            </Link>
          </main>
        }
      />
    </Routes>
  );
}
