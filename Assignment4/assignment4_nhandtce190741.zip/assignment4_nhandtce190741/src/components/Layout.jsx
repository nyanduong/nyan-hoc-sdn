import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import Icon from "./Icon";

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  return (
    <div className="workspace">
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <aside className="sidebar">
        <Link to="/reports" className="brand">
          <span className="brand-symbol">
            <Icon name="bug" size={23} />
          </span>
          bugdesk<span className="brand-dot">.</span>
        </Link>
        <div className="workspace-label">YOUR WORKSPACE</div>
        <nav aria-label="Main navigation" className="side-nav">
          <NavLink end to="/reports">
            <Icon name="grid" /> My reports
          </NavLink>
          {user.role === "admin" && (
            <NavLink to="/reports/create">
              <Icon name="plus" /> Create report
            </NavLink>
          )}
        </nav>
        <div className="sidebar-note">
          <span className="tiny-label">A LITTLE LESS CHAOS</span>
          <p>
            Better reports.
            <br />
            Smoother projects.
          </p>
          <div className="note-line" />
        </div>
        <div className="account">
          <div className="account-row">
            <span className="avatar">{user.email[0].toUpperCase()}</span>
            <div className="account-info">
              <strong title={user.email}>{user.email}</strong>
              <span className="text-capitalize">{user.role} account</span>
            </div>
          </div>
          <details className="account-details">
            <summary>My account ID</summary>
            <code>{user.id}</code>
          </details>
          <button
            className="logout-button"
            onClick={() => {
              logout();
              navigate("/signin", { replace: true });
            }}
          >
            <Icon name="logout" size={17} /> Sign out
          </button>
        </div>
      </aside>
      <div className="workspace-body">
        <header className="topbar">
          <span>
            Workspace <span className="breadcrumb-slash">/</span> Bug reports
          </span>
          <span className="course-label">
            SDN302 <span>Assignment 04</span>
          </span>
        </header>
        <main id="main-content" className="main-content">
          <Outlet />
        </main>
        <footer className="workspace-footer">
          <span>Bugdesk · Bug Report Management</span>
          <span>nhandtce190741</span>
        </footer>
      </div>
    </div>
  );
}
